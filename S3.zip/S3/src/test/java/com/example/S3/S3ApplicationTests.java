package com.example.S3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
